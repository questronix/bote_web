<template>
  <div id="app" class="flex-container">
    <h1>Login Page</h1>
    <input v-model="username" type="text" placeholder="Username"/>
    <input v-model="password" type="password" placeholder="Password"/>
    <button v-on:click="validateCredential(username,password)"> Log In </button>
  </div>
</template>

<script>
  export default{
    name: 'app',
    data: function(){
      return{
        username: '',
        password:'',
        credentials:{'user':'pass'}
      }
    },
    methods: {
    addCredential: function(username, password){
        if(!(this.credentials.hasOwnProperty(username))){
            this.credentials[username] = password;
            console.log(this.credentials);
        }else{
        alert(`Credentials of ${username} already exist`);
        }
    },
    validateCredential: function(username, password){
        //wrong credentials or nonexistent username, prompt error
        if(!(this.credentials.hasOwnProperty(username))){
          alert(`Wrong credentials`);
        }else if(this.credentials[username] !== password){
          alert(`Wrong password`);
        }else{
          alert(`${username} has successfully logged in`);
        }
    }
  }
 }
</script>

<style>
#app {
  align-items: center;
  justify-content: center;
}

.flex-container{
  display: flex;
  flex-direction: column;
}
html{
  background: linear-gradient(#221d42, #371e46);
  background-repeat: no-repeat;
  height: 100%
}
</style>