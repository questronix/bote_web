import Vue from 'vue/dist/vue';
import Login from './Login.vue';

new Vue({
  el: '#app',
  render: h => h(Login)
})