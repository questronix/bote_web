<template>
  <div id="app">
    <h1>Hello World!</h1>
    <button-counter></button-counter>
  </div>
</template>
