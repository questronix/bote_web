import Vue from 'vue/dist/vue';
import App from './App.vue';
import Login from '../login/Login.vue';
import button from '../../components/button';
import login from '../../components/login';

 new Vue({
  el: '#app',
  render: h => h(Login)
})